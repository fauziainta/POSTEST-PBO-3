package model;

public class Customer extends Person {
    private String usernameIg;

    public Customer(String nama, String usernameIg) {
        super(nama); 
        this.usernameIg = usernameIg;
    }

    public String getUsernameIg() {
        return usernameIg;
    }

    public void setUsernameIg(String usernameIg) {
        this.usernameIg = usernameIg;
    }

    @Override
    public String getRole() {
        return "Customer";
    }

    @Override
    public String toString() {
        return "Nama: " + getNama() + ", IG: " + usernameIg;
    }
}
