package model;

public class Reservation {
    private Customer customer;
    private String tanggal;
    private String waktu;
    private String layanan;
    private double harga; // harga asli sebelum diskon

    public Reservation(Customer customer, String tanggal, String waktu, String layanan, double harga) {
        this.customer = customer;
        this.tanggal = tanggal;
        this.waktu = waktu;
        this.layanan = layanan;
        this.harga = harga;
    }

    public Customer getCustomer() {
        return customer;
    }

    public String getTanggal() {
        return tanggal;
    }

    public void setTanggal(String tanggal) {
        this.tanggal = tanggal;
    }

    public String getWaktu() {
        return waktu;
    }

    public void setWaktu(String waktu) {
        this.waktu = waktu;
    }

    public String getLayanan() {
        return layanan;
    }

    public void setLayanan(String layanan) {
        this.layanan = layanan;
    }

    public double getHarga() {
        return harga;
    }

    public void setHarga(double harga) {
        this.harga = harga;
    }

    public double hitungTotal() {
        double total = harga;
        if (customer instanceof VIPCustomer vip) {
            total = total - (total * vip.getDiskon());
        }
        return total;
    }

    @Override
public String toString() {
    String tipeCustomer = (customer instanceof VIPCustomer) ? " (VIP)" : "";
    return "Nama: " + customer.getNama() + tipeCustomer +
           ", IG: " + customer.getUsernameIg() +
           ", Tanggal: " + tanggal +
           ", Waktu: " + waktu +
           ", Layanan: " + layanan +
           ", Harga: Rp" + harga +
           ", Total Bayar: Rp" + hitungTotal();
}

}
