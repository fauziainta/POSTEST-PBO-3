package model;

public class VIPCustomer extends Customer {
    private double diskon;

    public VIPCustomer(String nama, String usernameIg, double diskon) {
        super(nama, usernameIg);
        this.diskon = diskon;
    }

    public double getDiskon() {
        return diskon;
    }

    public void setDiskon(double diskon) {
        this.diskon = diskon;
    }

    @Override
    public String getRole() {
        return "VIP Customer";
    }

    @Override
    public String toString() {
        return super.toString() + ", Diskon: " + (diskon * 100) + "%";
    }
}
